package WxCrypto.utils.java;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;
import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.Base64;
// --- <<IS-END-IMPORTS>> ---

public final class aes256

{
	// ---( internal utility methods )---

	final static aes256 _instance = new aes256();

	static aes256 _newInstance() { return new aes256(); }

	static aes256 _cast(Object o) { return (aes256)o; }

	// ---( server methods )---




	public static final void decryptStr (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(decryptStr)>> ---
		// @sigtype java 3.5
		// [i] field:0:required secretKey
		// [i] field:0:required encryptedStr
		// [o] field:0:required actualStr
		// [o] field:0:optional errMsg
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	secretKey = IDataUtil.getString( pipelineCursor, "secretKey" );
			String	encryptedStr = IDataUtil.getString( pipelineCursor, "encryptedStr" );
		pipelineCursor.destroy();
		
		String actualStr=null;
		String errMsg=null;
		try{
		  byte[] iv = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		  IvParameterSpec ivspec = new IvParameterSpec(iv);
		 
		  SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
		  KeySpec spec = new PBEKeySpec(secretKey.toCharArray(), SALT.getBytes(), 65536, 256);
		  SecretKey tmp = factory.generateSecret(spec);
		  SecretKeySpec secretKey1 = new SecretKeySpec(tmp.getEncoded(), "AES");
		 
		  Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
		  cipher.init(Cipher.DECRYPT_MODE, secretKey1, ivspec);
		  actualStr=new String(cipher.doFinal(Base64.getDecoder().decode(encryptedStr)));
		}catch (NoSuchAlgorithmException e) {
			errMsg="No Such Algorithm : AES-256";
		}catch (InvalidKeySpecException e) {
			errMsg="Invalid Key Spec";
		}catch (NoSuchPaddingException e) {
			errMsg="No Such Padding : AES/CBC/PKCS5Padding";
		}catch (InvalidKeyException e) {
			errMsg="Invalid Secret Key : "+secretKey;
		}catch (Exception e) {
			e.printStackTrace();
		} 
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "actualStr", actualStr );
		IDataUtil.put( pipelineCursor_1, "errMsg", errMsg );
		pipelineCursor_1.destroy();			
		// --- <<IS-END>> ---

                
	}



	public static final void encryptStr (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(encryptStr)>> ---
		// @sigtype java 3.5
		// [i] field:0:required secretKey
		// [i] field:0:required inputStr
		// [o] field:0:required encryptedStr
		// [o] field:0:optional errMsg
		  // pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	secretKey = IDataUtil.getString( pipelineCursor, "secretKey" );
			String	inputStr = IDataUtil.getString( pipelineCursor, "inputStr" );
		pipelineCursor.destroy();
		
		String encryptedStr=null;
		String errMsg=null;
		try {
				  byte[] iv = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
			      IvParameterSpec ivspec = new IvParameterSpec(iv);
			 
			      SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
				
			      KeySpec spec = new PBEKeySpec(secretKey.toCharArray(), SALT.getBytes(), 65536, 256);
			      SecretKey tmp = factory.generateSecret(spec);
			      SecretKeySpec secretKey1 = new SecretKeySpec(tmp.getEncoded(), "AES");
			 
			      Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			      cipher.init(Cipher.ENCRYPT_MODE, secretKey1, ivspec);
			      encryptedStr= Base64.getEncoder().encodeToString(cipher.doFinal(inputStr.getBytes(StandardCharsets.UTF_8)));
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			errMsg="No Such Algorithm : AES-256";
		} catch (InvalidKeySpecException e) {
			// TODO Auto-generated catch block
			errMsg="Invalid Key Spec";
		} catch (NoSuchPaddingException e) {
			// TODO Auto-generated catch block
			errMsg="No Such Padding : AES/CBC/PKCS5Padding";
		} catch (InvalidKeyException e) {
			// TODO Auto-generated catch block
			errMsg="Invalid Secret Key : "+secretKey;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "encryptedStr", encryptedStr );
		IDataUtil.put( pipelineCursor, "errMsg", errMsg );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	public static final String SALT = "138d88894b527993e4d8f03c8d223a713ee240538162fd9cb9af49046c8819a5";
	// --- <<IS-END-SHARED>> ---
}

