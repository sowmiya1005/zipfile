package WxCrypto.utils.java;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;
import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.Base64;
import java.util.Random;
// --- <<IS-END-IMPORTS>> ---

public final class sha256

{
	// ---( internal utility methods )---

	final static sha256 _instance = new sha256();

	static sha256 _newInstance() { return new sha256(); }

	static sha256 _cast(Object o) { return (sha256)o; }

	// ---( server methods )---




	public static final void generateHash (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(generateHash)>> ---
		// @sigtype java 3.5
		// [i] field:0:required inputString
		// [o] field:0:required hashHexString
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	inputString = IDataUtil.getString( pipelineCursor, "inputString" );
		pipelineCursor.destroy();
		
		MessageDigest digest = null;
		try {
			digest = MessageDigest.getInstance("SHA-256");
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		byte[] encodedhash = digest.digest(inputString.getBytes(StandardCharsets.UTF_8));
		String hashHexString=bytesToHex(encodedhash);
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "hashHexString", hashHexString );
		pipelineCursor_1.destroy();
		
			
		// --- <<IS-END>> ---

                
	}



	public static final void generateHmac (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(generateHmac)>> ---
		// @sigtype java 3.5
		// [i] field:0:required secretKey
		// [i] field:0:required inputString
		// [o] field:0:required hmacHexString
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	inputString = IDataUtil.getString( pipelineCursor, "inputString" );
			String	secretKey = IDataUtil.getString( pipelineCursor, "secretKey" );
		pipelineCursor.destroy();
		
		byte[] secretKeyBytes = secretKey.getBytes(StandardCharsets.UTF_8);
		
		Mac mac;
		String hmacHexString=null;
		try {
			mac = Mac.getInstance("HmacSHA256");
			mac.init(new SecretKeySpec(secretKeyBytes, "HmacSHA256"));
		    hmacHexString=bytesToHex(mac.doFinal(inputString.getBytes(StandardCharsets.UTF_8)));
		} catch (NoSuchAlgorithmException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (InvalidKeyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "hmacHexString", hmacHexString );
		pipelineCursor_1.destroy();		
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	private static String bytesToHex(byte[] hash) {
	    StringBuilder hexString = new StringBuilder(2 * hash.length);
	    for (int i = 0; i < hash.length; i++) {
	        String hex = Integer.toHexString(0xff & hash[i]);
	        if(hex.length() == 1) {
	            hexString.append('0');
	        }
	        hexString.append(hex);
	    }
	    return hexString.toString();
	}
	// --- <<IS-END-SHARED>> ---
}

