package WxCrypto.utils.java;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import iaik.pkcs.pkcs12.SecretKeyGenerator;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;
import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.Arrays;
import java.util.Base64;
// --- <<IS-END-IMPORTS>> ---

public final class tripleDES128

{
	// ---( internal utility methods )---

	final static tripleDES128 _instance = new tripleDES128();

	static tripleDES128 _newInstance() { return new tripleDES128(); }

	static tripleDES128 _cast(Object o) { return (tripleDES128)o; }

	// ---( server methods )---




	public static final void decryptStr (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(decryptStr)>> ---
		// @sigtype java 3.5
		// [i] field:0:required secretKey
		// [i] field:0:required encryptedStr
		// [o] field:0:required actualStr
		// [o] field:0:optional errMsg
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	secretKey = IDataUtil.getString( pipelineCursor, "secretKey" );
			String	encryptedStr = IDataUtil.getString( pipelineCursor, "encryptedStr" );
		pipelineCursor.destroy();
		
		String actualStr=null;
		String errMsg=null;
		try{
				byte[] message = Base64.getDecoder().decode(encryptedStr.getBytes(StandardCharsets.UTF_8));	
		        MessageDigest md = MessageDigest.getInstance("MD5");
		        byte[] digestOfPassword = md.digest(secretKey.getBytes(StandardCharsets.UTF_8));
		        byte[] keyBytes = Arrays.copyOf(digestOfPassword, 24);
		        
		        for (int j = 0, k = 16; j < 8;) {
		            keyBytes[k++] = keyBytes[j++];
		        }
		        
		        SecretKey key = new SecretKeySpec(keyBytes, "DESede");
		
		        Cipher decipher = Cipher.getInstance("DESede/ECB/PKCS5Padding");
		        decipher.init(Cipher.DECRYPT_MODE, key);
		        actualStr=new String(decipher.doFinal(message), StandardCharsets.UTF_8);
		}catch (NoSuchAlgorithmException e) {
			errMsg="No Such Algorithm : 3DES";
		}catch (NoSuchPaddingException e) {
			errMsg="No Such Padding : desede/CBC/PKCS5Padding";
		}catch (InvalidKeyException e) {
			errMsg="Invalid Secret Key : "+secretKey;
		}catch (Exception e) {
			e.printStackTrace();
		} 
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "actualStr", actualStr );
		IDataUtil.put( pipelineCursor_1, "errMsg", errMsg );
		pipelineCursor_1.destroy();			
		// --- <<IS-END>> ---

                
	}



	public static final void encryptStr (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(encryptStr)>> ---
		// @sigtype java 3.5
		// [i] field:0:required secretKey
		// [i] field:0:required inputStr
		// [o] field:0:required encryptedStr
		// [o] field:0:optional errMsg
		  // pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	secretKey = IDataUtil.getString( pipelineCursor, "secretKey" );
			String	inputStr = IDataUtil.getString( pipelineCursor, "inputStr" );
		pipelineCursor.destroy();
		
		String encryptedStr=null;
		String errMsg=null;
		try {
		//				 	DESedeKeySpec spec = new DESedeKeySpec(secretKey.getBytes());
		//			        SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DESede");
		//			        Key desKey = keyFactory.generateSecret(spec);
		//			        Cipher cipher = Cipher.getInstance("DESede/CBC/PKCS5Padding");
		//		
		//			        IvParameterSpec iv = new IvParameterSpec(new byte[8]);
		//			        cipher.init(Cipher.ENCRYPT_MODE, desKey, iv);
		//		
		//			        byte[] encrypted = cipher.doFinal(inputStr.getBytes(StandardCharsets.UTF_8));
		//			        encryptedStr=Base64.getEncoder().encodeToString(encrypted);
			        
			        MessageDigest md = MessageDigest.getInstance("md5");
			        byte[] digestOfPassword = md.digest(secretKey.getBytes(StandardCharsets.UTF_8));
			        byte[] keyBytes = Arrays.copyOf(digestOfPassword, 24);
		
			        for (int j = 0, k = 16; j < 8;) {
			            keyBytes[k++] = keyBytes[j++];
			        }
		
			        SecretKey key = new SecretKeySpec(keyBytes, "DESede");
			        Cipher cipher = Cipher.getInstance("DESede/ECB/PKCS5Padding");
			        cipher.init(Cipher.ENCRYPT_MODE, key);
		
			        encryptedStr = new String(Base64.getEncoder().encode(cipher.doFinal(inputStr.getBytes(StandardCharsets.UTF_8))));
			        
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			errMsg="No Such Algorithm : Triple DES";
		} catch (NoSuchPaddingException e) {
			// TODO Auto-generated catch block
			errMsg="No Such Padding : DESede";
		} catch (InvalidKeyException e) {
			// TODO Auto-generated catch block
			errMsg="Invalid Secret Key : "+secretKey;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "encryptedStr", encryptedStr );
		IDataUtil.put( pipelineCursor, "errMsg", errMsg );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}
}

