package WxCrypto.utils.java;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;
import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.Base64;
import java.util.Random;
// --- <<IS-END-IMPORTS>> ---

public final class common

{
	// ---( internal utility methods )---

	final static common _instance = new common();

	static common _newInstance() { return new common(); }

	static common _cast(Object o) { return (common)o; }

	// ---( server methods )---




	public static final void generateSecretKey (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(generateSecretKey)>> ---
		// @sigtype java 3.5
		// [i] field:0:required algorithm {"AES","3DES","Blowfish"}
		// [o] field:0:required secretKey
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	algorithm = IDataUtil.getString( pipelineCursor, "algorithm" );
		pipelineCursor.destroy();
		
		
		SecretKey Symmetrickey = null;
		String secretKey=null;
		try {
			if (algorithm.equals("AES")) Symmetrickey = createAESKey();
			else if (algorithm.equals("3DES")) Symmetrickey = createTripleDESKey();
			else if (algorithm.equals("Blowfish")) Symmetrickey = createBlowfishKey();
			
			secretKey=DatatypeConverter.printHexBinary(Symmetrickey.getEncoded());
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// pipeline
		
		// pipeline
		IDataCursor pipelineCursor1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor1, "secretKey", secretKey);
		pipelineCursor1.destroy();
			
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	public static SecretKey createAESKey() throws Exception{
		KeyGenerator keygenerator = KeyGenerator.getInstance("AES");
		SecureRandom securerandom = SecureRandom.getInstance("SHA1PRNG");
		keygenerator.init(256, securerandom);
		return keygenerator.generateKey();
	}
	public static SecretKey createTripleDESKey() throws Exception{
		KeyGenerator keygenerator = KeyGenerator.getInstance("DESede");
		SecureRandom securerandom = SecureRandom.getInstance("SHA1PRNG");
		keygenerator.init(128, securerandom);
		return keygenerator.generateKey();
	}
	public static SecretKey createBlowfishKey() throws Exception{
		Random r = new Random();
		byte[] knumb = String.valueOf(r.nextInt(10000)).getBytes();
		KeyGenerator keygenerator = KeyGenerator.getInstance("Blowfish");
		SecureRandom securerandom = SecureRandom.getInstance("SHA1PRNG");
		securerandom.setSeed(knumb);
		keygenerator.init(64, securerandom);
		return keygenerator.generateKey();
	}
	// --- <<IS-END-SHARED>> ---
}

